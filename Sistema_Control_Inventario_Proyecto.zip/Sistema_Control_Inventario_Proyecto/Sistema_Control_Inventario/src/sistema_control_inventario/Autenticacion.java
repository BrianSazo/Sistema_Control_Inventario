/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema_control_inventario;
/**
 *
 * @author sazo
 */
import java.util.Scanner;
/**
 * Clase que maneja la autenticación de usuarios para acceder al sistema.
 */
public class Autenticacion {
    // son para el nombre de usuario y contraseña correctos
    private static final String CORRECT_USERNAME = "admin";
    private static final String CORRECT_PASSWORD = "admin";
     // Scanner para leer la entrada del usuario
    private static Scanner scanner = new Scanner(System.in);

    /**
     * Método principal para iniciar el proceso de la autenticación.
     */
    public static void main(String[] args) {
        if (authenticateUser()) {
            System.out.println("Autenticacion exitosa. Bienvenido al sistema.");
            // Si la autenticación es exitosa, esto crea una intancia y muestra el MenuPrincipal 
            MenuPrincipal menuPrincipal = new MenuPrincipal();
            menuPrincipal.Menu();
        } else {
            // Si la autenticación falla, muestra el mensaje de Autenticación fallida. Acceso denegado
            System.out.println("Autenticacion fallida. Acceso denegado.");
        }
    }

     /**
     * Método que maneja el proceso de autenticación del usuario.
     * @return true si la autenticación es exitosa, false en caso contrario.
     */
    private static boolean authenticateUser() {
        // contador para el número de intentos permitidos
        int oportunidades = 3; 
        while (oportunidades > 0) {
            // Solicita el nombre de usuario y la contraseña
            System.out.print("Usuario: ");
            String username = scanner.nextLine();
            System.out.print("Contrasena: ");
            String password = scanner.nextLine();

            // Verifica si lo que se ingreso anteriormente es correctas
            if (username.equals(CORRECT_USERNAME) && password.equals(CORRECT_PASSWORD)) {
                return true;
            // Si lo que se ingreso es incorrecto, reduce el número de intentos y muestra un mensaje
            } else {
                oportunidades--;
                System.out.println("Usuario o contrasena incorrectos. Intentos restantes: " + oportunidades);
            }
        }
        // se da como autenticación fallida después de que se acaben todos los intentos
        return false;
    }
}