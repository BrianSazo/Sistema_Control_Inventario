/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema_control_inventario;

/**
 *
 * @author sazo
 */
import java.io.*;
import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 * Clase que maneja el control de inventario del sistema.
 */
public class ControlInventario {
    private static final String ARCHIVO_PRODUCTOS = "productos.txt";
    private static final String ARCHIVO_MOVIMIENTOS = "movimientos.txt";
    private static final int PUNTO_REORDEN = 10; // Ejemplo de punto de reorden
    private Scanner scanner = new Scanner(System.in);

    /**
     * Muestra el menú de Control Inventario y maneja la interacción del usuario.
     */
    public void MenuControlInv() {
        while (true) {
            System.out.println("\n Control de Inventario");
            System.out.println("1. Registrar Entrada de Producto");
            System.out.println("2. Registrar Salida de Producto");
            System.out.println("3. Ver Historial de Movimientos de Stock");
            System.out.println("4. Verificar Niveles de Stock Bajo");
            System.out.println("5. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            
            int opcion = scanner.nextInt();
            // Consumir nueva línea
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    registrarEntradaProducto();
                    break;
                case 2:
                    registrarSalidaProducto();
                    break;
                case 3:
                    System.out.print("Ingrese el ID del producto: ");
                    String idProducto = scanner.nextLine();
                    verHistorialMovimientosStock(idProducto);
                    break;
                case 4:
                    verificarNivelesStockBajo();
                    break;
                case 5:
                    System.out.println("Volviendo al Menu Principal...");
                    return;
                default:
                    System.out.println("Opcion no valida. Por favor, intente de nuevo.");
            }
        }
    }

    public void registrarEntradaProducto() {
        System.out.print("Ingrese el ID del producto: ");
        String idProducto = scanner.nextLine();

        Producto producto = buscarProductoPorId(idProducto);
        if (producto == null) {
            System.out.println("Producto no encontrado.");
            return;
        }

        System.out.print("Ingrese la cantidad a agregar: ");
        int cantidad = scanner.nextInt();
        scanner.nextLine(); // Consumir nueva línea

        actualizarStock(producto, cantidad);
        registrarMovimiento(producto, cantidad, "ENTRADA");
        System.out.println("Entrada de productos registrada correctamente.");
    }

    public void registrarSalidaProducto() {
        System.out.print("Ingrese el ID del producto: ");
        String idProducto = scanner.nextLine();

        Producto producto = buscarProductoPorId(idProducto);
        if (producto == null) {
            System.out.println("Producto no encontrado.");
            return;
        }

        System.out.print("Ingrese la cantidad a vender: ");
        int cantidad = scanner.nextInt();
        scanner.nextLine(); // Consumir nueva línea

        if (cantidad > producto.stock) {
            System.out.println("Stock insuficiente. Disponible: " + producto.stock);
            return;
        }

        actualizarStock(producto, -cantidad);
        registrarMovimiento(producto, cantidad, "SALIDA");
        System.out.println("Salida de productos registrada correctamente.");
    }

    private Producto buscarProductoPorId(String id) {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_PRODUCTOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.equals("---")) continue;
                String[] partes = linea.split(",");
                if (partes.length >= 6 && partes[0].equals(id)) {
                    Producto producto = new Producto();
                    producto.id = partes[0];
                    producto.nombre = partes[1];
                    producto.descripcion = partes[3];
                    producto.precio = Double.parseDouble(partes[4]);
                    producto.stock = Integer.parseInt(partes[5]);
                    return producto;
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de productos: " + e.getMessage());
        }
        return null;
    }

    private void actualizarStock(Producto producto, int cambioCantidad) {
        producto.stock += cambioCantidad;
        actualizarArchivoProductos(producto);

        if (producto.stock <= PUNTO_REORDEN) {
            generarAlertaStockBajo(producto);
        }
    }

    private void actualizarArchivoProductos(Producto productoActualizado) {
        List<String> lineas = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_PRODUCTOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.startsWith(productoActualizado.id)) {
                    linea = productoActualizado.id + "," + productoActualizado.nombre + "," +
                            "," + productoActualizado.descripcion + "," + 
                            productoActualizado.precio + "," + productoActualizado.stock;
                }
                lineas.add(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de productos: " + e.getMessage());
            return;
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_PRODUCTOS))) {
            for (String linea : lineas) {
                writer.println(linea);
            }
        } catch (IOException e) {
            System.out.println("Error al escribir en el archivo de productos: " + e.getMessage());
        }
    }

    private void registrarMovimiento(Producto producto, int cantidad, String tipo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARCHIVO_MOVIMIENTOS, true))) {
            LocalDateTime ahora = LocalDateTime.now();
            String timestamp = ahora.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            writer.println(timestamp + "," + producto.id + "," + tipo + "," + cantidad);
        } catch (IOException e) {
            System.out.println("Error al registrar el movimiento: " + e.getMessage());
        }
    }

    private void generarAlertaStockBajo(Producto producto) {
        System.out.println("ALERTA DE STOCK BAJO:");
        System.out.println("Producto: " + producto.nombre);
        System.out.println("Stock actual: " + producto.stock);
        System.out.println("Punto de reorden: " + PUNTO_REORDEN);
    }

    public void verHistorialMovimientosStock(String idProducto) {
        System.out.println("Historial de Movimientos de Stock para el producto ID " + idProducto + ":");
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_MOVIMIENTOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes[1].equals(idProducto)) {
                    System.out.println("Fecha: " + partes[0] + ", Tipo: " + partes[2] + ", Cantidad: " + partes[3]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el historial de movimientos: " + e.getMessage());
        }
    }

    public void verificarNivelesStockBajo() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARCHIVO_PRODUCTOS))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                if (linea.equals("---")) continue;
                String[] partes = linea.split(",");
                if (partes.length >= 6) {
                    int stock = Integer.parseInt(partes[5]);
                    if (stock <= PUNTO_REORDEN) {
                        System.out.println("ALERTA DE STOCK BAJO:");
                        System.out.println("Producto: " + partes[1]);
                        System.out.println("Stock actual: " + stock);
                        System.out.println("Punto de reorden: " + PUNTO_REORDEN);
                        System.out.println("--------------------");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error al verificar niveles de stock bajo: " + e.getMessage());
        }
    }
}

