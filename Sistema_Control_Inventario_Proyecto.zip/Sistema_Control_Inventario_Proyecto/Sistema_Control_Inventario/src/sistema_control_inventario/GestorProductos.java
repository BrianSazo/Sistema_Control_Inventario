/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_control_inventario;

/**
 *
 * @author sazo
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.util.List;
/**
 * Clase que maneja la gestion de productos, categorias, especificaciones, caracteristicas, etc.
 */

// Clase que representa una categoría de producto
class Categoria {
    String nombre;
    String descripcion;
    
    // Constructor de la clase Categoria
    public Categoria(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
    
    // Método para comparar categorías ignorando mayúsculas
    boolean igualIgnorandoMayusculas(String filtroCategoria) {
        throw new UnsupportedOperationException("Aún no soportado."); // Generado desde nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

// Clase que representa una característica de producto
class Caracteristica {
    String nombre;
    String descripcion;
    
    // Constructor de la clase Caracteristica
    public Caracteristica(String nombre, String descripcion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
}

// Clase que representa una especificacion de producto
class Especificacion {
    String nombre;
    String descripcion;
    String tipoDeDato;

    // Constructor de la clase Especificacion
    public Especificacion(String nombre, String descripcion, String tipoDeDato) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tipoDeDato = tipoDeDato;
    }
}

// Clase principal que representa un producto
class Producto {
    String id;
    String nombre;
    Categoria categoria;
    String descripcion;
    List<Caracteristica> caracteristicas;
    List<Especificacion> especificaciones;
    double precio;
    int stock;

    // Constructor de la clase Producto
    public Producto() {
        this.caracteristicas = new ArrayList<>();
        this.especificaciones = new ArrayList<>();
    }
    
     // Método para obtener el precio
    Integer obtenerPrecio() {
        throw new UnsupportedOperationException("Aun no soportado."); // Generado desde nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

/**
 * Clase que maneja la gestión de productos, categorías, especificaciones, características, etc.
 */
// Clase principal que gestiona todo el sistema de productos
public class GestorProductos {
    // Listas para almacenar los diferentes elementos del sistema
    private List<Producto> productos = new ArrayList<>();
    private List<Categoria> categorias = new ArrayList<>();
    private List<Caracteristica> caracteristicas = new ArrayList<>();
    private List<Especificacion> especificaciones = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    
    
    // Método principal que muestra el menú de gestión de productos
    public void MenuGestPro() {
        while (true) {
            System.out.println("\n Gestion de Productos");
            System.out.println("1. Gestionar Categorias");
            System.out.println("2. Gestionar Caracteristicas");
            System.out.println("3. Gestionar Especificaciones");
            System.out.println("4. Agregar Producto");
            System.out.println("5. Actualizar Producto");
            System.out.println("6. Eliminar Producto");
            System.out.println("7. Listar Productos");
            System.out.println("8. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            int opcion = scanner.nextInt();
            // Consumir nueva línea
            scanner.nextLine(); 

            if (opcion == 8) {
                // Guardar todos los datos antes de salir
                guardarTodosDatos(); 
                break;
            }
            manejarOpcionProducto(opcion);
        }
    }
    
    // Método para manejar las opciones seleccionadas en el menú principal
    private void manejarOpcionProducto(int opcion) {
        switch (opcion) {
            case 1:
                gestionarCategorias();
                // Guardar después de cada operación
                guardarCategorias(); 
                break;
            case 2:
                gestionarCaracteristicas();
                // Guardar después de cada operación
                guardarCaracteristicas(); 
                break;
            case 3:
                gestionarEspecificaciones();
                // Guardar después de cada operación
                guardarEspecificaciones(); 
                break;
            case 4:
                agregarProducto();
                // Guardar después de cada operación
                guardarProductos(); 
                break;
            case 5:
                actualizarProducto();
                // Guardar después de cada operación
                guardarProductos(); 
                break;
            case 6:
                eliminarProducto();
                // Guardar después de cada operación
                guardarProductos(); 
                break;
            case 7:
                listarProductos();
                break;
            default:
                System.out.println("Opcion no valida. Por favor, intente de nuevo.");
        }
    }
    // Método para gestionar las categorías y menu de gestionar las categorias
    private void gestionarCategorias() {
        while (true) {
            System.out.println("\n Gestion de Categorias");
            System.out.println("1. Agregar Categoria");
            System.out.println("2. Modificar Categoria");
            System.out.println("3. Eliminar Categoria");
            System.out.println("4. Listar Categorias");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opcion: ");
            int opcion = scanner.nextInt();
            // Consumir nueva línea
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    agregarCategoria();
                    break;
                case 2:
                    actualizarCategoria();
                    break;
                case 3:
                    eliminarCategoria();
                    break;
                case 4:
                    listarCategorias();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Opcion no valida. Por favor, intente de nuevo.");
            }
        }
    }
    
    // Método para agregar una nueva categoría
    private void agregarCategoria() {
        System.out.print("Nombre de la categoria: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripcion de la categoria: ");
        String descripcion = scanner.nextLine();

        if (encontrarCategoriaPorNombre(nombre) == null) {
            categorias.add(new Categoria(nombre, descripcion));
            guardarCategorias();
            System.out.println("Categoria agregada correctamente.");
        } else {
            System.out.println("Ya existe una categoria con ese nombre.");
        }
    }

    // Método para actualizar una categoría existente
    private void actualizarCategoria() {
        listarCategorias();
        System.out.print("Ingrese el nombre de la categoria a modificar: ");
        String nombre = scanner.nextLine();
        Categoria categoria = encontrarCategoriaPorNombre(nombre);
        if (categoria != null) {
            System.out.print("Nuevo nombre (Enter para mantener actual): ");
            String nuevoNombre = scanner.nextLine();
            if (!nuevoNombre.isEmpty()) {
                if (encontrarCategoriaPorNombre(nuevoNombre) == null) {
                    categoria.nombre = nuevoNombre;
                } else {
                    System.out.println("Ya existe una categoria con ese nombre.");
                    return;
                }
            }
            System.out.print("Nueva descripcion (Enter para mantener actual): ");
            String nuevaDescripcion = scanner.nextLine();
            if (!nuevaDescripcion.isEmpty()) {
                categoria.descripcion = nuevaDescripcion;
            }
            guardarCategorias();
            System.out.println("Categoria actualizada correctamente.");
        } else {
            System.out.println("Categoria no encontrada.");
        }
    }
    
    // Método para eliminar una categoría
    private void eliminarCategoria() {
        listarCategorias();
        System.out.print("Ingrese el nombre de la categoria a eliminar: ");
        String nombre = scanner.nextLine();
        Categoria categoria = encontrarCategoriaPorNombre(nombre);
        if (categoria != null) {
            System.out.println("¿Está seguro de que desea eliminar la categoria? (S/N)");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("S")) {
                categorias.remove(categoria);
                guardarCategorias();
                System.out.println("Categoria eliminada correctamente.");
            } else {
                System.out.println("Operacion cancelada.");
            }
        } else {
            System.out.println("Categoria no encontrada.");
        }
    }

    // Método para listar todas las categorías
    private void listarCategorias() {
        System.out.println("\n Lista de Categorias");
        for (Categoria categoria : categorias) {
            System.out.println("Nombre: " + categoria.nombre);
            System.out.println("Descripcion: " + categoria.descripcion);
            System.out.println("--------------------");
        }
    }

    // Método para gestionar las características y menu de gestionar caracteristicas
    private void gestionarCaracteristicas() {
        while (true) {
            System.out.println("\n Gestion de Caracteristicas");
            System.out.println("1. Agregar Caracteristica");
            System.out.println("2. Modificar Caracteristica");
            System.out.println("3. Eliminar Caracteristica");
            System.out.println("4. Listar Caracteristicas");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opcion: ");
            int opcion = scanner.nextInt();
            // Consumir nueva línea
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    agregarCaracteristica();
                    break;
                case 2:
                    actualizarCaracteristica();
                    break;
                case 3:
                    eliminarCaracteristica();
                    break;
                case 4:
                    listarCaracteristicas();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Opcion no valida. Por favor, intente de nuevo.");
            }
        }
    }
    
    // Método para agregar una nueva característica
    private void agregarCaracteristica() {
        System.out.print("Nombre de la caracteristica: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripcion de la caracteristica: ");
        String descripcion = scanner.nextLine();

        if (encontrarCaracteristicaPorNombre(nombre) == null) {
            caracteristicas.add(new Caracteristica(nombre, descripcion));
            guardarCaracteristicas();
            System.out.println("Caracteristica agregada correctamente.");
        } else {
            System.out.println("Ya existe una característica con ese nombre.");
        }
    }

     // Método para actualizar una característica existente
    private void actualizarCaracteristica() {
        listarCaracteristicas();
        System.out.print("Ingrese el nombre de la caracteristica a modificar: ");
        String nombre = scanner.nextLine();
        Caracteristica caracteristica = encontrarCaracteristicaPorNombre(nombre);
        if (caracteristica != null) {
            System.out.print("Nuevo nombre (Enter para mantener actual): ");
            String nuevoNombre = scanner.nextLine();
            if (!nuevoNombre.isEmpty()) {
                if (encontrarCaracteristicaPorNombre(nuevoNombre) == null) {
                    caracteristica.nombre = nuevoNombre;
                } else {
                    System.out.println("Ya existe una caracteristica con ese nombre.");
                    return;
                }
            }
            System.out.print("Nueva descripcion (Enter para mantener actual): ");
            String nuevaDescripcion = scanner.nextLine();
            if (!nuevaDescripcion.isEmpty()) {
                caracteristica.descripcion = nuevaDescripcion;
            }
            guardarCaracteristicas();
            System.out.println("Caracteristica actualizada correctamente.");
        } else {
            System.out.println("Caracteristica no encontrada.");
        }
    }

    // Método para eliminar una característica
    private void eliminarCaracteristica() {
        listarCaracteristicas();
        System.out.print("Ingrese el nombre de la caracteristica a eliminar: ");
        String nombre = scanner.nextLine();
        Caracteristica caracteristica = encontrarCaracteristicaPorNombre(nombre);
        if (caracteristica != null) {
            System.out.println("¿Esta seguro de que desea eliminar la caracteristica? (S/N)");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("S")) {
                caracteristicas.remove(caracteristica);
                guardarCaracteristicas();
                System.out.println("Caracteristica eliminada correctamente.");
            } else {
                System.out.println("Operacion cancelada.");
            }
        } else {
            System.out.println("Caracteristica no encontrada.");
        }
    }

    // Método para listar todas las características
    private void listarCaracteristicas() {
        System.out.println("\n Lista de Caracteristicas");
        for (Caracteristica caracteristica : caracteristicas) {
            System.out.println("Nombre: " + caracteristica.nombre);
            System.out.println("Descripcion: " + caracteristica.descripcion);
            System.out.println("--------------------");
        }
    }

    // Método para gestionar las especificaciones y menu de gestionar las especificaciones
    private void gestionarEspecificaciones() {
        while (true) {
            System.out.println("\n Gestion de Especificaciones");
            System.out.println("1. Agregar Especificacion");
            System.out.println("2. Modificar Especificacion");
            System.out.println("3. Eliminar Especificacion");
            System.out.println("4. Listar Especificaciones");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opcion: ");
            int opcion = scanner.nextInt();
            // Consumir nueva línea
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    agregarEspecificacion();
                    break;
                case 2:
                    actualizarEspecificacion();
                    break;
                case 3:
                    eliminarEspecificacion();
                    break;
                case 4:
                    listarEspecificaciones();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Opcion no valida. Por favor, intente de nuevo.");
            }
        }
    }

    // Método para agregar una nueva especificación
    private void agregarEspecificacion() {
        System.out.print("Nombre de la especificacion: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripción de la especificacion: ");
        String descripcion = scanner.nextLine();
        System.out.print("Tipo de dato de la especificacion: ");
        String tipoDeDato = scanner.nextLine();

        if (encontrarEspecificacionPorNombre(nombre) == null) {
            especificaciones.add(new Especificacion(nombre, descripcion, tipoDeDato));
            guardarEspecificaciones();
            System.out.println("Especificacion agregada correctamente.");
        } else {
            System.out.println("Ya existe una especificacion con ese nombre.");
        }
    }

    
    private void actualizarEspecificacion() {
        listarEspecificaciones();
        System.out.print("Ingrese el nombre de la especificacion a modificar: ");
        String nombre = scanner.nextLine();
        Especificacion especificacion = encontrarEspecificacionPorNombre(nombre);
        if (especificacion != null) {
            System.out.print("Nuevo nombre (Enter para mantener actual): ");
            String nuevoNombre = scanner.nextLine();
            if (!nuevoNombre.isEmpty()) {
                if (encontrarEspecificacionPorNombre(nuevoNombre) == null) {
                    especificacion.nombre = nuevoNombre;
                } else {
                    System.out.println("Ya existe una especificacion con ese nombre.");
                    return;
                }
            }
            System.out.print("Nueva descripcion (Enter para mantener actual): ");
            String nuevaDescripcion = scanner.nextLine();
            if (!nuevaDescripcion.isEmpty()) {
                especificacion.descripcion = nuevaDescripcion;
            }
            System.out.print("Nuevo tipo de dato (Enter para mantener actual): ");
            String nuevoTipoDeDato = scanner.nextLine();
            if (!nuevoTipoDeDato.isEmpty()) {
                especificacion.tipoDeDato = nuevoTipoDeDato;
            }
            guardarEspecificaciones();
            System.out.println("Especificacion actualizada correctamente.");
        } else {
            System.out.println("Especificacion no encontrada.");
        }
    }

    private void eliminarEspecificacion() {
        listarEspecificaciones();
        System.out.print("Ingrese el nombre de la especificacion a eliminar: ");
        String nombre = scanner.nextLine();
        Especificacion especificacion = encontrarEspecificacionPorNombre(nombre);
        if (especificacion != null) {
            System.out.println("¿Esta seguro de que desea eliminar la especificacion? (S/N)");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("S")) {
                especificaciones.remove(especificacion);
                guardarEspecificaciones();
                System.out.println("Especificacion eliminada correctamente.");
            } else {
                System.out.println("Operacion cancelada.");
            }
        } else {
            System.out.println("Especificacion no encontrada.");
        }
    }

    private void listarEspecificaciones() {
        System.out.println("\n Lista de Especificaciones");
        for (Especificacion especificacion : especificaciones) {
            System.out.println("Nombre: " + especificacion.nombre);
            System.out.println("Descripcion: " + especificacion.descripcion);
            System.out.println("Tipo de dato: " + especificacion.tipoDeDato);
            System.out.println("--------------------");
        }
    }

// Método para agregar productos
public void agregarProducto() {
    Producto producto = new Producto();
    
    while (true) {
        System.out.print("ID del producto: ");
        String id = scanner.nextLine();
        if (encontrarProductoPorId(id) != null) {
            System.out.println("El ID ya ha sido registrado. Por favor, use otro ID.");
        } else {
            producto.id = id;
            break;
        }
    }

        System.out.print("Nombre del producto: ");
        producto.nombre = scanner.nextLine();
        System.out.print("Descripcion del producto: ");
        producto.descripcion = scanner.nextLine();

        listarCategorias();
        System.out.print("Nombre de la categoria del producto: ");
        String nombreCategoria = scanner.nextLine();
        producto.categoria = encontrarCategoriaPorNombre(nombreCategoria);

        System.out.print("Precio del producto: Q");
        producto.precio = scanner.nextDouble();
        System.out.print("Stock del producto: ");
        producto.stock = scanner.nextInt();
        scanner.nextLine();

        // Agregar características al producto
        while (true) {
            System.out.println("¿Desea agregar una característica al producto? (S/N)");
            String respuesta = scanner.nextLine();
            if (!respuesta.equalsIgnoreCase("S")) {
                break;
            }
            listarCaracteristicas();
            System.out.print("Seleccione el nombre de la característica: ");
            String nombreCaracteristica = scanner.nextLine();
            Caracteristica caracteristica = encontrarCaracteristicaPorNombre(nombreCaracteristica);
            if (caracteristica != null) {
                producto.caracteristicas.add(caracteristica);
            } else {
                System.out.println("Caracteristica no encontrada.");
            }
        }

        // Agregar especificaciones al producto
        while (true) {
            System.out.println("¿Desea agregar una especificacion al producto? (S/N)");
            String respuesta = scanner.nextLine();
            if (!respuesta.equalsIgnoreCase("S")) {
                break;
            }
            listarEspecificaciones();
            System.out.print("Seleccione el nombre de la especificacion: ");
            String nombreEspecificacion = scanner.nextLine();
            Especificacion especificacion = encontrarEspecificacionPorNombre(nombreEspecificacion);
            if (especificacion != null) {
                producto.especificaciones.add(especificacion);
            } else {
                System.out.println("Especificacion no encontrada.");
            }
        }

        productos.add(producto);
        System.out.println("Producto agregado correctamente.");
    }

    // Método para actualizar los productos
    private void actualizarProducto() {
        listarProductos();
        System.out.print("Ingrese el ID del producto a actualizar: ");
        String id = scanner.nextLine();
        Producto producto = encontrarProductoPorId(id);
        if (producto != null) {
            System.out.print("Nuevo nombre (Enter para mantener actual): ");
            String nuevoNombre = scanner.nextLine();
            if (!nuevoNombre.isEmpty()) {
                producto.nombre = nuevoNombre;
            }
            System.out.print("Nueva descripcion (Enter para mantener actual): ");
            String nuevaDescripcion = scanner.nextLine();
            if (!nuevaDescripcion.isEmpty()) {
                producto.descripcion = nuevaDescripcion;
            }
            System.out.print("Nuevo precio (Enter para mantener actual): ");
            String nuevoPrecio = scanner.nextLine();
            if (!nuevoPrecio.isEmpty()) {
                producto.precio = Double.parseDouble(nuevoPrecio);
            }
            System.out.print("Nuevo stock (Enter para mantener actual): ");
            String nuevoStock = scanner.nextLine();
            if (!nuevoStock.isEmpty()) {
                producto.stock = Integer.parseInt(nuevoStock);
            }
            guardarProductos();
            System.out.println("Producto actualizado correctamente.");
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    // Método para eliminar los productos 
    private void eliminarProducto() {
        listarProductos();
        System.out.print("Ingrese el ID del producto a eliminar: ");
        String id = scanner.nextLine();
        Producto producto = encontrarProductoPorId(id);
        if (producto != null) {
            System.out.println("¿Esta seguro de que desea eliminar el producto? (S/N)");
            String confirmacion = scanner.nextLine();
            if (confirmacion.equalsIgnoreCase("S")) {
                productos.remove(producto);
                guardarProductos();
                System.out.println("Producto eliminado correctamente.");
            } else {
                System.out.println("Operacion cancelada.");
            }
        } else {
            System.out.println("Producto no encontrado.");
        }
    }

    // Método para listar los productos
    private void listarProductos() {
        System.out.println("\n Lista de Productos");
        for (Producto producto : productos) {
            System.out.println("ID: " + producto.id);
            System.out.println("Nombre: " + producto.nombre);
            System.out.println("Categoria: " + (producto.categoria != null ? producto.categoria.nombre : "N/A"));
            System.out.println("Precio: " + producto.precio);
            System.out.println("Stock: " + producto.stock);
            System.out.println("--------------------");
        }
    }

    // Método para guardar los productos en un archivo
    void guardarProductos() {
        try (PrintWriter escritor = new PrintWriter(new FileWriter("productos.txt"))) {
            for (Producto producto : productos) {
                escritor.println(producto.id + "," + producto.nombre + "," + 
                               (producto.categoria != null ? producto.categoria.nombre : "") + "," + 
                               producto.descripcion + "," + producto.precio + "," + producto.stock);
                // Guardar características
                for (Caracteristica caracteristica : producto.caracteristicas) {
                    escritor.println("C:" + caracteristica.nombre);
                }
                // Guardar especificaciones
                for (Especificacion especificacion : producto.especificaciones) {
                    escritor.println("E:" + especificacion.nombre);
                }
                // Separador entre productos
                escritor.println("---"); 
            }
        } catch (IOException e) {
            System.out.println("Error al guardar los productos: " + e.getMessage());
        }
    }

    // Método para cargar los productos desde un archivo
    private void cargarProductos() {
        productos.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader("productos.txt"))) {
            String linea;
            Producto productoActual = null;
            while ((linea = lector.readLine()) != null) {
                // Para cargar productos, características y especificaciones
                if (linea.equals("---")) {
                    if (productoActual != null) {
                        productos.add(productoActual);
                        productoActual = null;
                    }
                } else if (linea.startsWith("C:")) {
                    if (productoActual != null) {
                        Caracteristica caracteristica = encontrarCaracteristicaPorNombre(linea.substring(2));
                        if (caracteristica != null) {
                            productoActual.caracteristicas.add(caracteristica);
                        }
                    }
                } else if (linea.startsWith("E:")) {
                    if (productoActual != null) {
                        Especificacion especificacion = encontrarEspecificacionPorNombre(linea.substring(2));
                        if (especificacion != null) {
                            productoActual.especificaciones.add(especificacion);
                        }
                    }
                } else {
                    String[] partes = linea.split(",");
                    if (partes.length == 6) {
                        productoActual = new Producto();
                        productoActual.id = partes[0];
                        productoActual.nombre = partes[1];
                        productoActual.categoria = encontrarCategoriaPorNombre(partes[2]);
                        productoActual.descripcion = partes[3];
                        productoActual.precio = Double.parseDouble(partes[4]);
                        productoActual.stock = Integer.parseInt(partes[5]);
                    }
                }
            }
            if (productoActual != null) {
                productos.add(productoActual);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar los productos: " + e.getMessage());
        }
    }

    private void guardarCategorias() {
        try (PrintWriter escritor = new PrintWriter(new FileWriter("categorias.txt"))) {
            for (Categoria categoria : categorias) {
                escritor.println(categoria.nombre + "," + categoria.descripcion);
            }
        } catch (IOException e) {
            System.out.println("Error al guardar las categorias: " + e.getMessage());
        }
    }

    private void cargarCategorias() {
        categorias.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader("categorias.txt"))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    categorias.add(new Categoria(partes[0], partes[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar las categorias: " + e.getMessage());
        }
    }

    private void guardarCaracteristicas() {
        try (PrintWriter escritor = new PrintWriter(new FileWriter("caracteristicas.txt"))) {
            for (Caracteristica caracteristica : caracteristicas) {
                escritor.println(caracteristica.nombre + "," + caracteristica.descripcion);
            }
        } catch (IOException e) {
            System.out.println("Error al guardar las caracteristicas: " + e.getMessage());
        }
    }

    private void cargarCaracteristicas() {
        caracteristicas.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader("caracteristicas.txt"))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    caracteristicas.add(new Caracteristica(partes[0], partes[1]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar las caracteristicas: " + e.getMessage());
        }
    }

    private void guardarEspecificaciones() {
        try (PrintWriter escritor = new PrintWriter(new FileWriter("especificaciones.txt"))) {
            for (Especificacion especificacion : especificaciones) {
                escritor.println(especificacion.nombre + "," + especificacion.descripcion + "," + especificacion.tipoDeDato);
            }
        } catch (IOException e) {
            System.out.println("Error al guardar las especificaciones: " + e.getMessage());
        }
    }

    private void cargarEspecificaciones() {
        especificaciones.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader("especificaciones.txt"))) {
            String linea;
            while ((linea = lector.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3) {
                    especificaciones.add(new Especificacion(partes[0], partes[1], partes[2]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar las especificaciones: " + e.getMessage());
        }
    }

    private Categoria encontrarCategoriaPorNombre(String nombre) {
        for (Categoria categoria : categorias) {
            if (categoria.nombre.equals(nombre)) {
                return categoria;
            }
        }
        return null;
    }

    private Caracteristica encontrarCaracteristicaPorNombre(String nombre) {
        for (Caracteristica caracteristica : caracteristicas) {
            if (caracteristica.nombre.equals(nombre)) {
                return caracteristica;
            }
        }
        return null;
    }

    private Especificacion encontrarEspecificacionPorNombre(String nombre) {
        for (Especificacion especificacion : especificaciones) {
            if (especificacion.nombre.equals(nombre)) {
                return especificacion;
            }
        }
        return null;
    }

    Producto encontrarProductoPorId(String id) {
        for (Producto producto : productos) {
            if (producto.id.equals(id)) {
                return producto;
            }
        }
        return null;
    }

    // Método para guardar todos los datos
    private void guardarTodosDatos() {
        guardarCategorias();
        guardarCaracteristicas();
        guardarEspecificaciones();
        guardarProductos();
    }

    // Método principal para ejecutar el programa
    public static void main(String[] args) {
        GestorProductos gestor = new GestorProductos();
        
        // Cargar todos los datos al inicio del programa
        gestor.cargarCategorias();
        gestor.cargarCaracteristicas();
        gestor.cargarEspecificaciones();
        gestor.cargarProductos();
        
        gestor.MenuGestPro();
    }

    // Método de la clase InformesEstadisticas aun no soportado
    List<Producto> obtenerTodosLosProductos() {
        throw new UnsupportedOperationException("aun no soportado."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
