/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_control_inventario;

/**
 *
 * @author sazo
 */

import java.util.*;
import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 * Clase que maneja los informes y estadisticas del sistema.
 */

public class InformesEstadisticas {
    private GestorProductos gestorProductos;
    private PedidosCompra pedidosCompra;
    private ControlInventario controlInventario;
    private Scanner scanner;
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter FORMATO_FECHA_HORA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public InformesEstadisticas(GestorProductos gestorProductos, ControlInventario controlInventario, PedidosCompra pedidosCompra) {
        this.gestorProductos = gestorProductos;
        this.pedidosCompra = pedidosCompra;
        this.scanner = new Scanner(System.in);
    }

    public void MenuInformes() {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n Informes y Estadisticas");
            System.out.println("1. Informe de Inventario Actual");
            System.out.println("2. Informe de Movimientos de Stock");
            System.out.println("3. Informe de Compras");
            System.out.println("4. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            
            try {
                int opcion = Integer.parseInt(scanner.nextLine());
                switch (opcion) {
                    case 1:
                        generarInformeInventarioActual();
                        break;
                    case 2:
                        generarInformeMovimientosStock();
                        break;
                    case 3:
                        generarInformeCompras();
                        break;
                    case 4:
                        salir = true;
                        break;
                    default:
                        System.out.println("Opcion no valida. Por favor, intente de nuevo.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Por favor, ingrese un número valido.");
            }
        }
    }

    private void generarInformeInventarioActual() {
        System.out.println("\n Informe de Inventario Actual");
        System.out.print("¿Desea filtrar por categoria? (S/N): ");
        boolean filtrarPorCategoria = scanner.nextLine().equalsIgnoreCase("S");
        String categoriaFiltro = "";
        if (filtrarPorCategoria) {
            System.out.print("Ingrese la categoria: ");
            categoriaFiltro = scanner.nextLine();
        }

        List<Producto> productos = gestorProductos.obtenerTodosLosProductos();
        List<String[]> informeData = new ArrayList<>();

        for (Producto producto : productos) {
            if (!filtrarPorCategoria || (producto.categoria != null && producto.categoria.nombre.equalsIgnoreCase(categoriaFiltro))) {
                double valorTotalStock = producto.precio * producto.stock;
                String[] fila = {
                    producto.nombre,
                    producto.categoria != null ? producto.categoria.nombre : "Sin categoria",
                    String.valueOf(producto.stock),
                    String.format("%.2f", valorTotalStock),
                    "Punto de reorden 10"
                };
                informeData.add(fila);
            }
        }

        System.out.print("Ordenar por (1-Nombre, 2-Stock, 3-Valor Total): ");
        int criterioOrden = scanner.nextInt();
        scanner.nextLine(); // Consumir nueva línea

        switch (criterioOrden) {
            case 1:
                informeData.sort(Comparator.comparing(a -> a[0]));
                break;
            case 2:
                informeData.sort(Comparator.comparing(a -> Integer.parseInt(a[2])));
                break;
            case 3:
                informeData.sort(Comparator.comparing(a -> Double.parseDouble(a[3])));
                break;
            default:
                System.out.println("Criterio de orden no valido. No se aplicara orden.");
        }

        // Imprimir informe en consola
        System.out.println("\n Nombre | Categoria | Stock | Valor Total | Punto de Reorden");
        for (String[] fila : informeData) {
            System.out.println(String.join(" | ", fila));
        }

        // Exportar a CSV
        System.out.print("¿Desea exportar el informe a CSV? (S/N): ");
        if (scanner.nextLine().equalsIgnoreCase("S")) {
            exportarACSV("informe_inventario.csv", new String[]{"Nombre", "Categoria", "Stock", "Valor Total", "Punto de Reorden"}, informeData);
        }
    }

    private void generarInformeMovimientosStock() {
        System.out.println("\n Informe de Movimientos de Stock");
        System.out.print("Ingrese el ID del producto: ");
        String idProducto = scanner.nextLine();
        System.out.print("Fecha inicial (AAAA-MM-DD): ");
        LocalDate fechaInicial = LocalDate.parse(scanner.nextLine(), FORMATO_FECHA);
        System.out.print("Fecha final (AAAA-MM-DD): ");
        LocalDate fechaFinal = LocalDate.parse(scanner.nextLine(), FORMATO_FECHA);

        List<String[]> movimientos = obtenerMovimientosStock(idProducto, fechaInicial, fechaFinal);

        // Imprimir informe en consola
        System.out.println("\n Fecha | Hora | Operacion | Cantidad | Usuario");
        for (String[] movimiento : movimientos) {
            System.out.println(String.join(" | ", movimiento));
        }

        // Exportar a CSV
        System.out.print("¿Desea exportar el informe a CSV? (S/N): ");
        if (scanner.nextLine().equalsIgnoreCase("S")) {
            exportarACSV("informe_movimientos_stock.csv", new String[]{"Fecha", "Hora", "Operacion", "Cantidad", "Usuario"}, movimientos);
        }
    }

    private List<String[]> obtenerMovimientosStock(String idProducto, LocalDate fechaInicial, LocalDate fechaFinal) {
        List<String[]> movimientos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("movimientos.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                LocalDateTime fecha = LocalDateTime.parse(parts[0], FORMATO_FECHA_HORA);
                if (parts[1].equals(idProducto) && !fecha.toLocalDate().isBefore(fechaInicial) && !fecha.toLocalDate().isAfter(fechaFinal)) {
                    movimientos.add(new String[]{
                        fecha.toLocalDate().toString(),
                        fecha.toLocalTime().toString(),
                        parts[2], 
                        parts[3], 
                        parts[4]  
                    });
                }
            }
        } catch (IOException e) {
            System.out.println("Error al leer el archivo de movimientos de stock: " + e.getMessage());
        }
        return movimientos;
    }

    private void generarInformeCompras() {
        System.out.println("\n Informe de Compras");
        System.out.print("Ingrese el ID del proveedor: ");
        String idProveedor = scanner.nextLine();
        System.out.print("Fecha inicial (AAAA-MM-DD): ");
        LocalDate fechaInicial = LocalDate.parse(scanner.nextLine(), FORMATO_FECHA);
        System.out.print("Fecha final (AAAA-MM-DD): ");
        LocalDate fechaFinal = LocalDate.parse(scanner.nextLine(), FORMATO_FECHA);

        List<String[]> compras = obtenerCompras(idProveedor, fechaInicial, fechaFinal);

        // Imprimir informe en consola
        System.out.println("\nFecha | Numero de Pedido | Producto | Cantidad | Precio Unitario | Total");
        for (String[] compra : compras) {
            System.out.println(String.join(" | ", compra));
        }

        // Exportar a CSV
        System.out.print("¿Desea exportar el informe a CSV? (S/N): ");
        if (scanner.nextLine().equalsIgnoreCase("S")) {
            exportarACSV("informe_compras.csv", new String[]{"Fecha", "Numero de Pedido", "Producto", "Cantidad", "Precio Unitario", "Total"}, compras);
        }
    }

    private List<String[]> obtenerCompras(String idProveedor, LocalDate fechaInicial, LocalDate fechaFinal) {
        List<String[]> compras = new ArrayList<>();
        for (OrdenCompra orden : pedidosCompra.obtenerOrdenesCompra()) {
            if (orden.idProveedor.equals(idProveedor) && 
                !orden.fechaCreacion.isBefore(fechaInicial) && 
                !orden.fechaCreacion.isAfter(fechaFinal)) {
                for (Map.Entry<String, Integer> entrada : orden.productos.entrySet()) {
                    Producto producto = gestorProductos.encontrarProductoPorId(entrada.getKey());
                    if (producto != null) {
                        double total = producto.precio * entrada.getValue();
                        compras.add(new String[]{
                            orden.fechaCreacion.toString(),
                            orden.id,
                            producto.nombre,
                            String.valueOf(entrada.getValue()),
                            String.format("%.2f", producto.precio),
                            String.format("%.2f", total)
                        });
                    }
                }
            }
        }
        return compras;
    }

    private void exportarACSV(String nombreArchivo, String[] encabezados, List<String[]> datos) {
        try (PrintWriter writer = new PrintWriter(new File(nombreArchivo))) {
            // Escribir encabezados
            writer.println(String.join(",", encabezados));

            // Escribir datos
            for (String[] fila : datos) {
                writer.println(String.join(",", fila));
            }

            System.out.println("Informe exportado exitosamente a " + nombreArchivo);
        } catch (FileNotFoundException e) {
            System.out.println("Error al exportar el informe: " + e.getMessage());
        }
    }
}
