/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_control_inventario;

/**
 *
 * @author sazo
 */
import java.util.Scanner;
import java.util.InputMismatchException;

/**
 * Clase que maneja el menú principal del sistema de control de inventario.
 */
public class MenuPrincipal {
    // sirven para manejar la entrada del usuario y los diferentes módulos del sistema
    private final Scanner scanner;
    private final GestorProductos gestorProductos;
    private final ControlInventario controlInventario;
    private final PedidosCompra pedidosCompra;
    private final InformesEstadisticas informesEstadisticas;

    /**
     * esto es lo que inicializa todos los componentes del sistema.
     */
    public MenuPrincipal() {
        this.scanner = new Scanner(System.in);
        this.gestorProductos = new GestorProductos();
        this.controlInventario = new ControlInventario();
        this.pedidosCompra = new PedidosCompra(gestorProductos);
        this.informesEstadisticas = new InformesEstadisticas(gestorProductos, controlInventario, pedidosCompra);
    }

    /**
     * Muestra el menú principal y maneja la interacción del usuario.
     */
    public void Menu() {
        boolean salir = false;
        while (!salir) {
            // Muestra las opciones del menú principal
            System.out.println("\n Menu Principal");
            System.out.println("1. Gestion de Productos");
            System.out.println("2. Control de Existencias");
            System.out.println("3. Pedidos de Compra");
            System.out.println("4. Informes y Estadisticas");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");

            try {
                // Lee la opción seleccionada por el usuario
                int opcion = scanner.nextInt();
                scanner.nextLine(); // Consume la nueva línea

                if (opcion == 5) {
                    // Si el usuario elige salir, termina el bucle
                    salir = true;
                    System.out.println("Gracias por usar el sistema. ¡Hasta luego!");
                } else {
                    // Procesa la opción seleccionada
                    procesarSeleccion(opcion);
                }
            } catch (InputMismatchException e) {
                // Maneja entradas no válidas (no numéricas)
                System.out.println("Por favor, ingrese un numero valido.");
                scanner.nextLine(); // Limpia la entrada inválida
            }
        }
        
        // Cierra el scanner al finalizar para liberar recursos
        scanner.close();
    }

    /**
     * Procesa la selección del usuario y llama al submenu correspondiente.
     * @param opcion La opción seleccionada por el usuario.
     */
    private void procesarSeleccion(int opcion) {
        switch (opcion) {
            case 1:
                gestorProductos.MenuGestPro();
                break;
            case 2:
                controlInventario.MenuControlInv();
                break;
            case 3:
                pedidosCompra.MenuPedidos();
                break;
            case 4:
                informesEstadisticas.MenuInformes();
                break;
            default:
                System.out.println("Opcion no valida. Por favor, intente de nuevo.");
        }
    }
}