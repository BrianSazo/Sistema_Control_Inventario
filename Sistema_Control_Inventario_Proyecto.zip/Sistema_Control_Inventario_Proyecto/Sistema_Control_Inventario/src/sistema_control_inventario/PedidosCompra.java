/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_control_inventario;

/**
 *
 * @author sazo
 */
import java.io.*;
import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

// Clase para representar una orden de compra
class OrdenCompra {
    String id;
    String idProveedor;
    LocalDate fechaCreacion;
    LocalDate fechaEntregaEstimada;
    Map<String, Integer> productos; 
    double total;
    String estado;

    public OrdenCompra(String id, String idProveedor, LocalDate fechaCreacion, LocalDate fechaEntregaEstimada) {
        this.id = id;
        this.idProveedor = idProveedor;
        this.fechaCreacion = fechaCreacion;
        this.fechaEntregaEstimada = fechaEntregaEstimada;
        this.productos = new HashMap<>();
        this.total = 0.0;
        this.estado = "pendiente";
    }
}

/**
 * Clase que maneja los Pedidos.
 */
public class PedidosCompra {
    private List<OrdenCompra> ordenesCompra;
    private GestorProductos gestorProductos;
    private Scanner scanner;
    private static final String ARCHIVO_PEDIDOS = "pedidos.txt";
    private static final DateTimeFormatter FORMATO_FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public PedidosCompra(GestorProductos gestorProductos) {
        this.ordenesCompra = new ArrayList<>();
        this.gestorProductos = gestorProductos;
        this.scanner = new Scanner(System.in);
        cargarOrdenesCompra();
    }

    public void MenuPedidos() {
        while (true) {
            System.out.println("\n Gestion de Pedidos de Compra");
            System.out.println("1. Crear Pedido de Compra");
            System.out.println("2. Ver Lista de Pedidos");
            System.out.println("3. Ver Detalles de Pedido");
            System.out.println("4. Modificar Estado de Pedido");
            System.out.println("5. Cancelar Pedido");
            System.out.println("6. Recibir Pedido");
            System.out.println("7. Volver al Menu Principal");
            System.out.print("Seleccione una opcion: ");
            int opcion = scanner.nextInt();
            scanner.nextLine(); // Consumir nueva línea

            switch (opcion) {
                case 1:
                    crearOrdenCompra();
                    break;
                case 2:
                    listarOrdenesCompra();
                    break;
                case 3:
                    verDetallesOrdenCompra();
                    break;
                case 4:
                    modificarEstadoOrdenCompra();
                    break;
                case 5:
                    cancelarOrdenCompra();
                    break;
                case 6:
                    recibirOrdenCompra();
                    break;
                case 7:
                    guardarOrdenesCompra();
                    return;
                default:
                    System.out.println("Opcion no valida. Por favor, intente de nuevo.");
            }
        }
    }

    private void crearOrdenCompra() {
        System.out.print("Ingrese el ID del proveedor: ");
        String idProveedor = scanner.nextLine();

        String idOrden = generarIdOrden();
        LocalDate fechaCreacion = LocalDate.now();
        System.out.print("Ingrese la fecha estimada de entrega (AAAA-MM-DD): ");
        LocalDate fechaEntregaEstimada = LocalDate.parse(scanner.nextLine(), FORMATO_FECHA);

        OrdenCompra orden = new OrdenCompra(idOrden, idProveedor, fechaCreacion, fechaEntregaEstimada);

        Map<String, Integer> productosParaPedido = new HashMap<>();
        boolean stockSuficiente = true;

        while (true) {
            System.out.print("Ingrese el ID del producto a agregar (o 'fin' para terminar): ");
            String idProducto = scanner.nextLine();
            if (idProducto.equalsIgnoreCase("fin")) {
                break;
            }

            Producto producto = gestorProductos.encontrarProductoPorId(idProducto);
            if (producto == null) {
                System.out.println("Producto no encontrado.");
                continue;
            }

            System.out.print("Ingrese la cantidad a comprar: ");
            int cantidad = scanner.nextInt();
            scanner.nextLine(); // Consumir nueva línea

            if (cantidad > producto.stock) {
                System.out.println("Error: Stock insuficiente. Stock actual: " + producto.stock);
                stockSuficiente = false;
                break;
            }

            productosParaPedido.put(idProducto, cantidad);
            orden.total += producto.precio * cantidad;
        }

        if (!stockSuficiente) {
            System.out.println("No se puede crear el pedido debido a falta de stock.");
            return;
        }

        System.out.println("Total del pedido: Q" + orden.total);
        System.out.print("¿Confirmar pedido? (S/N): ");
        if (scanner.nextLine().equalsIgnoreCase("S")) {
            // Actualizar el stock y agregar productos al pedido
            for (Map.Entry<String, Integer> entry : productosParaPedido.entrySet()) {
                String idProducto = entry.getKey();
                int cantidad = entry.getValue();
                Producto producto = gestorProductos.encontrarProductoPorId(idProducto);
                producto.stock -= cantidad;
                orden.productos.put(idProducto, cantidad);
            }

            ordenesCompra.add(orden);
            guardarOrdenesCompra();
            gestorProductos.guardarProductos(); // Guardar los cambios en el stock
            System.out.println("Pedido creado correctamente con ID: " + idOrden);
        } else {
            System.out.println("Creacion de pedido cancelada.");
        }
    }
    private void listarOrdenesCompra() {
        System.out.println("\n Lista de Pedidos de Compra");
        System.out.print("Filtrar por (1-Proveedor | 2-Fecha | 3-Estado | 4-Producto | 5-Todos): ");
        int opcionFiltro = scanner.nextInt();
        scanner.nextLine(); // Consumir nueva línea

        List<OrdenCompra> ordenesFiltradas = new ArrayList<>(ordenesCompra);

        switch (opcionFiltro) {
            case 1:
                System.out.print("Ingrese el ID del proveedor: ");
                String idProveedor = scanner.nextLine();
                ordenesFiltradas.removeIf(orden -> !orden.idProveedor.equals(idProveedor));
                break;
            case 2:
                System.out.print("Ingrese la fecha (AAAA-MM-DD): ");
                LocalDate fecha = LocalDate.parse(scanner.nextLine(), FORMATO_FECHA);
                ordenesFiltradas.removeIf(orden -> !orden.fechaCreacion.equals(fecha));
                break;
            case 3:
                System.out.print("Ingrese el estado (pendiente, en curso, completado): ");
                String estado = scanner.nextLine();
                ordenesFiltradas.removeIf(orden -> !orden.estado.equalsIgnoreCase(estado));
                break;
            case 4:
                System.out.print("Ingrese el ID del producto: ");
                String idProducto = scanner.nextLine();
                ordenesFiltradas.removeIf(orden -> !orden.productos.containsKey(idProducto));
                break;
            case 5:
                // Sin filtro, mostrar todas las órdenes
                break;
            default:
                System.out.println("Opcion no valida. Mostrando todos los pedidos.");
        }

        for (OrdenCompra orden : ordenesFiltradas) {
            System.out.println("ID: " + orden.id + ", Proveedor: " + orden.idProveedor + 
                               ", Fecha: " + orden.fechaCreacion + ", Estado: " + orden.estado);
        }
    }

    private void verDetallesOrdenCompra() {
        System.out.print("Ingrese el ID del pedido: ");
        String idOrden = scanner.nextLine();
        OrdenCompra orden = encontrarOrdenCompraPorId(idOrden);
        
        if (orden != null) {
            System.out.println("\n Detalles del Pedido");
            System.out.println("ID: " + orden.id);
            System.out.println("Proveedor: " + orden.idProveedor);
            System.out.println("Fecha de creacion: " + orden.fechaCreacion);
            System.out.println("Fecha de entrega estimada: " + orden.fechaEntregaEstimada);
            System.out.println("Estado: " + orden.estado);
            System.out.println("Productos:");
            for (Map.Entry<String, Integer> entrada : orden.productos.entrySet()) {
                Producto producto = gestorProductos.encontrarProductoPorId(entrada.getKey());
                System.out.println("  - " + producto.nombre + ": " + entrada.getValue() + " unidades");
            }
            System.out.println("Total: Q" + orden.total);
        } else {
            System.out.println("Pedido no encontrado.");
        }
    }

    private void modificarEstadoOrdenCompra() {
        System.out.print("Ingrese el ID del pedido: ");
        String idOrden = scanner.nextLine();
        OrdenCompra orden = encontrarOrdenCompraPorId(idOrden);
        
        if (orden != null) {
            System.out.print("Ingrese el nuevo estado (pendiente, en curso, completado): ");
            String nuevoEstado = scanner.nextLine();
            orden.estado = nuevoEstado;
            guardarOrdenesCompra();
            System.out.println("Estado del pedido actualizado correctamente.");
        } else {
            System.out.println("Pedido no encontrado.");
        }
    }

    private void cancelarOrdenCompra() {
        System.out.print("Ingrese el ID del pedido a cancelar: ");
        String idOrden = scanner.nextLine();
        OrdenCompra orden = encontrarOrdenCompraPorId(idOrden);
        
        if (orden != null && !orden.estado.equalsIgnoreCase("completado")) {
            // Restaurar el stock
            for (Map.Entry<String, Integer> entry : orden.productos.entrySet()) {
                String idProducto = entry.getKey();
                int cantidad = entry.getValue();
                Producto producto = gestorProductos.encontrarProductoPorId(idProducto);
                producto.stock += cantidad;
            }
            
            ordenesCompra.remove(orden);
            guardarOrdenesCompra();
            gestorProductos.guardarProductos(); // Guardar los cambios en el stock
            System.out.println("Pedido cancelado correctamente y stock restaurado.");
        } else if (orden == null) {
            System.out.println("Pedido no encontrado.");
        } else {
            System.out.println("No se puede cancelar un pedido completado.");
        }
    }

    private void recibirOrdenCompra() {
        System.out.print("Ingrese el ID del pedido a recibir: ");
        String idOrden = scanner.nextLine();
        OrdenCompra orden = encontrarOrdenCompraPorId(idOrden);
        
        if (orden != null && orden.estado.equalsIgnoreCase("pendiente")) {
            boolean todosProductosRecibidos = true;
            for (Map.Entry<String, Integer> entrada : orden.productos.entrySet()) {
                String idProducto = entrada.getKey();
                int cantidadOrdenada = entrada.getValue();
                
                System.out.print("Cantidad recibida de " + idProducto + " (ordenado: " + cantidadOrdenada + "): ");
                int cantidadRecibida = scanner.nextInt();
                scanner.nextLine(); // Consumir nueva línea
                
                if (cantidadRecibida > cantidadOrdenada) {
                    System.out.println("Advertencia: Exceso de productos recibidos.");
                } else if (cantidadRecibida < cantidadOrdenada) {
                    System.out.println("Advertencia: Faltan productos por recibir.");
                    todosProductosRecibidos = false;
                }
                
                // Actualizar el stock del producto
                Producto producto = gestorProductos.encontrarProductoPorId(idProducto);
                if (producto != null) {
                    producto.stock += cantidadRecibida;
                }
            }
            
            if (todosProductosRecibidos) {
                orden.estado = "completado";
            } else {
                orden.estado = "en curso";
            }
            
            guardarOrdenesCompra();
            gestorProductos.guardarProductos();
            
            // Generar registro de recepción
            generarRegistroRecepcion(orden);
            
            System.out.println("Pedido recibido y stock actualizado.");
        } else if (orden == null) {
            System.out.println("Pedido no encontrado.");
        } else {
            System.out.println("Este pedido no está pendiente de recepcion.");
        }
    }

    private void generarRegistroRecepcion(OrdenCompra orden) {
        try (PrintWriter escritor = new PrintWriter(new FileWriter("recepciones.txt", true))) {
            escritor.println("Fecha: " + LocalDate.now());
            escritor.println("Hora: " + java.time.LocalTime.now());
            escritor.println("Pedido ID: " + orden.id);
            escritor.println("Productos recibidos:");
            for (Map.Entry<String, Integer> entrada : orden.productos.entrySet()) {
                escritor.println("  - " + entrada.getKey() + ": " + entrada.getValue());
            }
            escritor.println("--------------------");
        } catch (IOException e) {
            System.out.println("Error al generar el registro de recepción: " + e.getMessage());
        }
    }

    private String generarIdOrden() {
        return "OC" + System.currentTimeMillis();
    }

    private OrdenCompra encontrarOrdenCompraPorId(String id) {
        for (OrdenCompra orden : ordenesCompra) {
            if (orden.id.equals(id)) {
                return orden;
            }
        }
        return null;
    }
    private void guardarOrdenesCompra() {
        try (PrintWriter escritor = new PrintWriter(new FileWriter(ARCHIVO_PEDIDOS))) {
            for (OrdenCompra orden : ordenesCompra) {
                escritor.println(orden.id + "," + orden.idProveedor + "," + 
                               orden.fechaCreacion + "," + orden.fechaEntregaEstimada + "," +
                               orden.estado + "," + orden.total);
                for (Map.Entry<String, Integer> entrada : orden.productos.entrySet()) {
                    escritor.println(entrada.getKey() + ":" + entrada.getValue());
                }
                escritor.println("---"); // Separador entre pedidos
            }
        } catch (IOException e) {
            System.out.println("Error al guardar los pedidos: " + e.getMessage());
        }
    }

    private void cargarOrdenesCompra() {
        ordenesCompra.clear();
        try (BufferedReader lector = new BufferedReader(new FileReader(ARCHIVO_PEDIDOS))) {
            String linea;
            OrdenCompra ordenActual = null;
            while ((linea = lector.readLine()) != null) {
                if (linea.equals("---")) {
                    if (ordenActual != null) {
                        ordenesCompra.add(ordenActual);
                        ordenActual = null;
                    }
                } else if (linea.contains(":")) {
                    if (ordenActual != null) {
                        String[] partes = linea.split(":");
                        ordenActual.productos.put(partes[0], Integer.parseInt(partes[1]));
                    }
                } else {
                    String[] partes = linea.split(",");
                    if (partes.length == 6) {
                        ordenActual = new OrdenCompra(
                            partes[0], partes[1], 
                            LocalDate.parse(partes[2]), 
                            LocalDate.parse(partes[3])
                        );
                        ordenActual.estado = partes[4];
                        ordenActual.total = Double.parseDouble(partes[5]);
                    }
                }
            }
            if (ordenActual != null) {
                ordenesCompra.add(ordenActual);
            }
        } catch (IOException e) {
            System.out.println("Error al cargar los pedidos: " + e.getMessage());
        }
    }

    public Iterable<OrdenCompra> obtenerOrdenesCompra() {
        return new ArrayList<>(ordenesCompra);
    }
}